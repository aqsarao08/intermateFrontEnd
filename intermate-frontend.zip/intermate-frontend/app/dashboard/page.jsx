"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import useUserStore from "@/store/userStore";

export default function DashboardPage() {
  const router = useRouter();
  const user = useUserStore((state) => state.user);
  const setUser = useUserStore((state) => state.setUser);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check if user exists in Zustand store
    if (!user) {
      // Try getting user from localStorage
      const storedUser = localStorage.getItem("user");
      if (storedUser) {
        setUser(JSON.parse(storedUser));
      } else {
        // Redirect to login if no user found
        router.push("/auth/login");
        return;
      }
    }
    setLoading(false);
  }, [user, router, setUser]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Loading...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-8 bg-gray-100">
      <h1 className="text-3xl font-bold mb-4">Welcome, {user?.name}!</h1>
      <p>This is your dashboard. You can add your menu, orders, or other features here.</p>
      <button
        className="mt-6 bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600"
        onClick={() => {
          localStorage.removeItem("user");
          setUser(null);
          router.push("/auth/login");
        }}
      >
        Logout
      </button>
    </div>
  );
}
