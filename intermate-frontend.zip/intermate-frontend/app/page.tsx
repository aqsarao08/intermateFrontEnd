"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import useUserStore from "@/store/userStore";

export default function Home() {
  const router = useRouter();
  const { token } = useUserStore();

  useEffect(() => {
    if (token) {
      router.push("/dashboard");
    } else {
      router.push("/auth/login");
    }
  }, [token]);

  return null;
}
