"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import useUserStore from "../../store/userStore";
import { useRouter } from "next/navigation";

export default function Header() {
  const pathname = usePathname();
  const user = useUserStore((state) => state.user);
  const setUser = useUserStore((state) => state.setUser);
  const router = useRouter();

  const handleLogout = () => {
    localStorage.removeItem("user");
    setUser(null);
    router.push("/auth/login");
  };

  const navLinks = [
    { name: "Home", path: "/" },
    { name: "Menu", path: "/menu" },
    { name: "Search", path: "/search" },
    { name: "Contact Us", path: "/contact" },
    { name: "About Us", path: "/about" },
  ];

  return (
    <header className="bg-white shadow-md">
      <div className="container mx-auto flex justify-between items-center p-4">
        <h1 className="text-xl font-bold">MyApp</h1>
        <nav className="flex items-center gap-6">
          {navLinks.map((link) => (
            <Link
              key={link.path}
              href={link.path}
              className={`hover:text-blue-500 ${
                pathname === link.path ? "text-blue-600 font-semibold" : "text-gray-700"
              }`}
            >
              {link.name}
            </Link>
          ))}

          {user ? (
            <button
              onClick={handleLogout}
              className="bg-red-500 text-white px-3 py-1 rounded hover:bg-red-600"
            >
              Logout
            </button>
          ) : (
            <>
              <Link
                href="/auth/login"
                className={`px-3 py-1 border rounded hover:bg-gray-100 ${
                  pathname === "/auth/login" ? "bg-gray-200" : ""
                }`}
              >
                Login
              </Link>
              <Link
                href="/auth/signup"
                className={`px-3 py-1 border rounded hover:bg-gray-100 ${
                  pathname === "/auth/signup" ? "bg-gray-200" : ""
                }`}
              >
                Signup
              </Link>
            </>
          )}
        </nav>
      </div>
    </header>
  );
}
