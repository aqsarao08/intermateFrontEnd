export default function ContactPage() {
  return <div className="p-8">Contact Us Page</div>;
}
