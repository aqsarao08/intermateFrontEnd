export default function MenuPage() {
  return <div className="p-8">Menu Page</div>;
}
