"use client";

import { useRouter } from "next/navigation";

export default function InterviewStartPage() {
  const router = useRouter();

  return (
    <div className="min-h-screen bg-gray-100 p-10">
      <div className="max-w-3xl mx-auto bg-white p-8 rounded-xl shadow-lg">
        <h1 className="text-3xl font-bold mb-4">AI Mock Interview</h1>

        <p className="text-gray-700 mb-4">
          You are about to begin an AI-powered mock interview. Your video and audio 
          will be recorded and analyzed to generate feedback on:
        </p>

        <ul className="list-disc ml-6 text-gray-700 mb-4">
          <li>Communication skills</li>
          <li>Confidence level</li>
          <li>Facial expressions</li>
         <li>Verbal clarity and filler words</li>
          <li>Time management</li>
        </ul>

        <p className="text-gray-700 mb-6">
          Please make sure you have a stable internet connection, your camera & 
          microphone are working, and you are in a quiet environment.
        </p>

        <button
          onClick={() => router.push("/interview")}
          className="bg-blue-600 text-white px-6 py-3 rounded-lg text-lg hover:bg-blue-700"
        >
          Start Interview
        </button>
      </div>
    </div>
  );
}
