"use client";

import { useEffect, useState } from "react";
import api from "@/services/api";

export default function InterviewResultPage() {
  const [feedback, setFeedback] = useState(null);

  useEffect(() => {
    const loadFeedback = async () => {
      try {
        const id = localStorage.getItem("interviewId");
        const res = await api.get(`/interviews/feedback/${id}`);
        setFeedback(res.data);
      } catch (err) {
        console.error("Error loading feedback");
      }
    };

    loadFeedback();
  }, []);

  if (!feedback)
    return <div className="p-10 text-center">⏳ Analyzing your interview…</div>;

  return (
    <div className="min-h-screen p-10 bg-gray-100">
      <div className="max-w-4xl mx-auto bg-white p-8 rounded-xl shadow-lg">
        <h1 className="text-3xl font-bold mb-4">Interview Feedback 🎉</h1>

        {/* Score */}
        <p className="text-xl mb-3">
          ⭐ Overall Score:{" "}
          <span className="text-green-600 font-bold">{feedback.score}</span>
        </p>

        {/* Strengths */}
        <h2 className="text-xl font-semibold">Strengths</h2>
        <ul className="list-disc ml-8 mb-4">
          {feedback.strengths?.map((s, i) => (
            <li key={i}>{s}</li>
          ))}
        </ul>

        {/* Weaknesses */}
        <h2 className="text-xl font-semibold">Areas to Improve</h2>
        <ul className="list-disc ml-8 mb-4">
          {feedback.weaknesses?.map((w, i) => (
            <li key={i}>{w}</li>
          ))}
        </ul>

        {/* Suggestions */}
        <h2 className="text-xl font-semibold">Suggestions</h2>
        <p className="bg-gray-50 p-4 rounded-lg border">
          {feedback.suggestions}
        </p>
      </div>
    </div>
  );
}
