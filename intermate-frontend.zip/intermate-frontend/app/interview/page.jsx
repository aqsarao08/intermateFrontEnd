"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import useUserStore from "@/store/userStore";
import api from "@/services/api";
import Webcam from "react-webcam";

export default function InterviewRoom() {
  const router = useRouter();
  const { user } = useUserStore();

  const webcamRef = useRef(null);
  const mediaRecorderRef = useRef(null);
  const [recording, setRecording] = useState(false);
  const [chunks, setChunks] = useState([]);
  const [questionIndex, setQuestionIndex] = useState(0);

  // Example interview questions (replace with API later)
  const questions = [
    "Tell me about yourself.",
    "Why do you want this role?",
    "Describe a challenge you faced.",
  ];

  // Timer
  const [seconds, setSeconds] = useState(0);

  useEffect(() => {
    let timer;
    if (recording) {
      timer = setInterval(() => setSeconds((s) => s + 1), 1000);
    }
    return () => clearInterval(timer);
  }, [recording]);

  // Start Recording
  const startRecording = async () => {
    setChunks([]);
    setSeconds(0);

    const stream = webcamRef.current.stream;

    mediaRecorderRef.current = new MediaRecorder(stream, {
      mimeType: "video/webm; codecs=vp9",
    });

    mediaRecorderRef.current.ondataavailable = (event) => {
      if (event.data.size > 0) {
        uploadChunk(event.data);
      }
    };

    mediaRecorderRef.current.start(5000); // every 5 seconds → chunk upload
    setRecording(true);

    // Create new interview session
    const createSession = async () => {
      try {
        const res = await api.post("/interviews/start", {
          userId: user?._id,
        });

        localStorage.setItem("interviewId", res.data.interviewId);
      } catch (err) {
        console.error("Failed to create interview session");
      }
    };

    await createSession();

  };

  // Stop Recording
  const stopRecording = () => {
    mediaRecorderRef.current.stop();
    setRecording(false);
  };

  // Upload Chunk to Backend
  const uploadChunk = async (blob) => {
    const form = new FormData();
    form.append("chunk", blob);
    form.append("question", questionIndex);

    try {
      await api.post("/interviews/upload-chunk", form, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      console.log("Chunk uploaded!");
    } catch (err) {
      console.error("Chunk upload error:", err);
    }
  };

  // Next Question
  const nextQuestion = () => {
    if (questionIndex < questions.length - 1) {
      setQuestionIndex(questionIndex + 1);
      setSeconds(0);
    } else {
      alert("Interview Completed!");
      router.push("/dashboard");
    }
  };
  /* const [questions, setQuestions] = useState([]);

useEffect(() => {
  const fetchQuestions = async () => {
    try {
      const res = await api.get("/interviews/questions"); 
      setQuestions(res.data.questions);
    } catch (err) {
      console.error("Failed to load questions", err);
    }
  };

  fetchQuestions();
}, []);
 */

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      {/* Title */}
      <h1 className="text-3xl font-semibold mb-6 text-gray-800">
        Mock Interview Room 🎥
      </h1>

      {/* Content layout */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
        
        {/* LEFT: Camera */}
        <div className="bg-white p-6 rounded-xl shadow-md">
          <h2 className="text-xl font-semibold mb-4">Camera Preview</h2>

          <Webcam
            ref={webcamRef}
            className="rounded-lg w-full aspect-video border"
            audio={true}
          />

          <div className="mt-4 flex gap-4">

            {!recording ? (
              <button
                onClick={startRecording}
                className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700"
              >
                Start Recording
              </button>
            ) : (
              <button
                onClick={stopRecording}
                className="bg-red-600 text-white px-6 py-2 rounded-lg hover:bg-red-700"
              >
                Stop Recording
              </button>
            )}

            <button
              onClick={nextQuestion}
              className="bg-indigo-600 text-white px-6 py-2 rounded-lg hover:bg-indigo-700"
            >
              Next Question
            </button>
          </div>

          {/* Timer */}
          <p className="mt-3 text-gray-600">⏳ Time: {seconds}s</p>
        </div>

        {/* RIGHT: Questions */}
        <div className="bg-white p-6 rounded-xl shadow-md">
          <h2 className="text-xl font-semibold mb-4">Current Question</h2>

          <div className="p-4 border rounded-lg bg-gray-50 text-lg">
            {questions[questionIndex]}
          </div>

          <p className="mt-4 text-gray-500">
            Question {questionIndex + 1} of {questions.length}
          </p>
        </div>
      </div>
    </div>
  );
}
