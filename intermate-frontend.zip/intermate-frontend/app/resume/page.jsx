"use client";

import { useState } from "react";
import api from "@/services/api";

export default function ResumeOptimizerPage() {
  const [file, setFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);

  const handleUpload = async () => {
    if (!file) {
      alert("Please select a resume file!");
      return;
    }

    setLoading(true);
    setResult(null);

    const form = new FormData();
    form.append("resume", file);

    try {
      const res = await api.post("/resume/optimize", form, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      setResult(res.data);
    } catch (err) {
      console.error(err);
      alert("Upload failed!");
    }

    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <h1 className="text-3xl font-semibold mb-6 text-gray-800">
        Resume Optimizer 📄
      </h1>

      {/* Upload Box */}
      <div className="bg-white p-6 rounded-xl shadow-md max-w-xl mx-auto">
        <label className="block mb-4 font-medium">
          Upload your Resume (PDF or DOCX):
        </label>

        <input
          type="file"
          accept=".pdf, .docx"
          onChange={(e) => setFile(e.target.files[0])}
          className="w-full border p-2 rounded-lg"
        />

        <button
          onClick={handleUpload}
          className="mt-4 bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 w-full"
        >
          Optimize Resume
        </button>
      </div>

      {/* Loading */}
      {loading && (
        <div className="text-center mt-10 text-lg text-gray-600">
          ⏳ Optimizing your resume, please wait...
        </div>
      )}

      {/* Results */}
      {result && (
        <div className="mt-10 bg-white p-6 rounded-xl shadow-md">
          
          <h2 className="text-2xl font-semibold mb-4 text-gray-800">
            AI Resume Analysis
          </h2>

          {/* Score */}
          <p className="text-lg font-medium mb-2">
            ⭐ Overall Score:{" "}
            <span className="text-green-600 font-bold">
              {result.score || "N/A"}
            </span>
          </p>

          {/* Strengths */}
          <h3 className="text-xl font-medium mt-4 mb-2">Strengths:</h3>
          <ul className="list-disc ml-6 text-gray-700">
            {result.strengths?.map((s, i) => (
              <li key={i}>{s}</li>
            ))}
          </ul>

          {/* Weaknesses */}
          <h3 className="text-xl font-medium mt-4 mb-2">Areas to Improve:</h3>
          <ul className="list-disc ml-6 text-gray-700">
            {result.weaknesses?.map((w, i) => (
              <li key={i}>{w}</li>
            ))}
          </ul>

          {/* Suggestions */}
          <h3 className="text-xl font-medium mt-4 mb-2">Suggestions:</h3>
          <p className="bg-gray-50 p-4 rounded-lg border text-gray-700 whitespace-pre-line">
            {result.suggestions || "No suggestions provided."}
          </p>

        </div>
      )}
    </div>
  );
}
