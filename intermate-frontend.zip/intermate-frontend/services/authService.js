// services/authService.js
import api from "./api";

/*const authService = {
  signup: async (payload) => {
    const res = await api.post("/auth/signup", payload);
    return res.data;
  },

  signin: async (payload) => {
    const res = await api.post("/auth/signin", payload);
    return res.data;
  },

  getProfile: async () => {
    const res = await api.get("/auth/me");
    return res.data;
  },

  signout: async () => {
    try {
      const res = await api.post("/auth/signout");
      return res.data;
    } catch (err) {
      return null;
    }
  },
}; 
export default authService;
*/

const signup = async (data) => {
  // Mock user
  const mockUser = { id: 1, name: data.name, email: data.email };
  
  // Simulate network delay
  await new Promise((resolve) => setTimeout(resolve, 500));

  // Always succeed for frontend development
  return {
    user: mockUser,
    token: "mock-jwt-token-123",
  };
};

const signin = async (data) => {
  // Mock user
  const mockUser = { id: 1, name: "Aisha", email: "aisha@example.com" };
  const mockPassword = "123456";

  await new Promise((resolve) => setTimeout(resolve, 500));

  if (data.email === mockUser.email && data.password === mockPassword) {
    return { user: mockUser, token: "mock-jwt-token-123" };
  } else {
    throw new Error("Invalid email or password");
  }
};

export default { signup, signin };