// services/api.js
import axios from "axios";

const api = axios.create({
  baseURL: "http://localhost:5000/api", // change to your backend URL
  withCredentials: true, // include cookies if backend uses them
});

// Attach token automatically
api.interceptors.request.use((config) => {
  if (typeof window !== "undefined") {
    const token = localStorage.getItem("token");
    if (token && config.headers) {
      config.headers.Authorization = `Bearer ${token}`;
    }
  }
  return config;
});

export default api;
