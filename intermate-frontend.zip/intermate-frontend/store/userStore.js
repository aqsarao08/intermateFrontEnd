// store/userStore.js
import { create } from "zustand";

const useUserStore = create((set) => ({
  user: null,
  token: null,

  setUser: (user) => set({ user }),

  setToken: (token) => {
    if (typeof window !== "undefined") {
      if (token) {
        localStorage.setItem("token", token);
      } else {
        localStorage.removeItem("token");
      }
    }
    set({ token });
  },

  clearAuth: () => {
    if (typeof window !== "undefined") {
      localStorage.removeItem("token");
    }
    set({ user: null, token: null });
  },
}));

export default useUserStore;
